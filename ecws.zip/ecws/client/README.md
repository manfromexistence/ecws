# `npm start`

Runs the app in the development mode at [http://localhost:3000](http://localhost:3000)

## `npm run build`

Builds the app for production to the `build` folder
