export { default as SellerPrivateRoute } from "./SellerPrivateRoute";
export { default as UserPrivateRoute } from "./UserPrivateRoute";
