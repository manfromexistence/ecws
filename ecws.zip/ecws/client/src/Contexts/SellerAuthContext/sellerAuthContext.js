import { createContext } from "react";

const sellerAuthContext = createContext();

export default sellerAuthContext;
