import { createContext } from "react";

const userAuthContext = createContext();

export default userAuthContext;
