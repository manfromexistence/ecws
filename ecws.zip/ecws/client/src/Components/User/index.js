export { default as Profile } from "./Profile/Profile";
export { default as EditProfile } from "./EditProfile/EditProfile";
export { default as ChangePass } from "./ChangePass/ChangePass";
export { default as LogoutModal } from "./LogoutModal/LogoutModal";
export { default as PurchasedItems } from "./PurchasedItems/PurchasedItems";
