export const MenuItems = [
	{
		title: "Sneakers",
		path: "/category?category=shoes",
		value: "shoes",
	},
	{
		title: "Hoodies",
		path: "/category?category=hoodies",
		value: "hoodies",
	},
	{
		title: "Bagpacks",
		path: "/category?category=bagpacks",
		value: "bagpacks",
	},
	{
		title: "T-shirts",
		path: "/category?category=tshirts",
		value: "tshirts",
	},
];
